import React from 'react';
import { Search, MapPin, Filter } from 'lucide-react';
import { SearchFilters } from '../types';

interface SearchFilterProps {
  filters: SearchFilters;
  onFilterChange: (filters: SearchFilters) => void;
}

export default function SearchFilter({ filters, onFilterChange }: SearchFilterProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    onFilterChange({
      ...filters,
      [name]: name === 'location' ? value : Number(value),
    });
  };

  return (
    <div className="bg-white p-6 rounded-3xl shadow-xl shadow-stone-200/50 border border-stone-100 -mt-12 relative z-10 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
            <MapPin size={12} /> Location
          </label>
          <input
            type="text"
            name="location"
            placeholder="Search city..."
            value={filters.location}
            onChange={handleChange}
            className="w-full bg-stone-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-stone-900 font-medium"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
            Min Price
          </label>
          <input
            type="number"
            name="minPrice"
            placeholder="0"
            value={filters.minPrice || ''}
            onChange={handleChange}
            className="w-full bg-stone-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-stone-900 font-medium"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
            Max Price
          </label>
          <input
            type="number"
            name="maxPrice"
            placeholder="Any"
            value={filters.maxPrice || ''}
            onChange={handleChange}
            className="w-full bg-stone-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-stone-900 font-medium"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-400 uppercase tracking-widest flex items-center gap-2">
            Rooms
          </label>
          <select
            name="rooms"
            value={filters.rooms}
            onChange={handleChange}
            className="w-full bg-stone-50 border-none rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none text-stone-900 font-medium appearance-none"
          >
            <option value={0}>Any rooms</option>
            <option value={1}>1+ Room</option>
            <option value={2}>2+ Rooms</option>
            <option value={3}>3+ Rooms</option>
            <option value={4}>4+ Rooms</option>
          </select>
        </div>
      </div>
    </div>
  );
}
