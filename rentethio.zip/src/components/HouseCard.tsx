import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, BedDouble, Phone } from 'lucide-react';
import { House } from '../types';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';

interface HouseCardProps {
  house: House;
  className?: string;
  key?: string | number;
}

export default function HouseCard({ house, className }: HouseCardProps) {
  const mainImage = house.images?.[0] || `https://picsum.photos/seed/${house.id}/800/600`;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className={cn("bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-sm hover:shadow-xl transition-all group", className)}
    >
      <Link to={`/house/${house.id}`} className="block relative aspect-[4/3] overflow-hidden">
        <img 
          src={mainImage} 
          alt={house.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-white/90 backdrop-blur-sm text-stone-900 px-3 py-1 rounded-full text-sm font-bold shadow-sm">
            {formatCurrency(house.price)}/mo
          </span>
        </div>
      </Link>

      <div className="p-5">
        <div className="flex items-center gap-1 text-emerald-600 mb-2">
          <MapPin size={14} />
          <span className="text-xs font-bold uppercase tracking-wider">{house.location}</span>
        </div>
        
        <Link to={`/house/${house.id}`}>
          <h3 className="text-lg font-bold text-stone-900 mb-2 line-clamp-1 group-hover:text-emerald-600 transition-colors">
            {house.title}
          </h3>
        </Link>

        <div className="flex items-center gap-4 text-stone-500 text-sm mb-4">
          <div className="flex items-center gap-1.5">
            <BedDouble size={16} className="text-stone-400" />
            <span>{house.rooms} Rooms</span>
          </div>
        </div>

        <div className="pt-4 border-top border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-500">
              <Phone size={14} />
            </div>
            <span className="text-sm font-medium text-stone-700">{house.landlordPhone}</span>
          </div>
          <Link 
            to={`/house/${house.id}`}
            className="text-sm font-bold text-emerald-600 hover:underline"
          >
            Details
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
