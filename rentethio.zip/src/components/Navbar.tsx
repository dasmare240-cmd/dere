import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Home, Search, PlusSquare, LogIn, LogOut, User } from 'lucide-react';
import { useAuth } from '../App';
import { auth, googleProvider, signInWithPopup, signOut } from '../firebase';
import { cn } from '../lib/utils';

export default function Navbar() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed', error);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-stone-200 z-50">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-emerald-200 group-hover:scale-105 transition-transform">
            <Home size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight text-stone-900">RentEthio</span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          <Link to="/listings" className="text-stone-600 hover:text-emerald-600 font-medium transition-colors">Browse</Link>
          {user && (
            <Link to="/post" className="text-stone-600 hover:text-emerald-600 font-medium transition-colors">Post House</Link>
          )}
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex flex-col items-end">
                <span className="text-sm font-semibold text-stone-900">{profile?.displayName}</span>
                <span className="text-xs text-stone-500 capitalize">{profile?.role}</span>
              </div>
              <button 
                onClick={handleLogout}
                className="p-2 text-stone-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="flex items-center gap-2 bg-stone-900 text-white px-5 py-2 rounded-xl hover:bg-stone-800 transition-all font-medium shadow-lg shadow-stone-200"
            >
              <LogIn size={18} />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
