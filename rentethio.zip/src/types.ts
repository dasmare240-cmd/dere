import { Timestamp } from 'firebase/firestore';

export interface House {
  id: string;
  landlordId: string;
  landlordName?: string;
  landlordPhone: string;
  landlordTelegram?: string;
  landlordEmail?: string;
  title: string;
  description: string;
  price: number;
  location: string;
  rooms: number;
  images?: string[];
  createdAt: Timestamp;
}

export interface UserProfile {
  uid: string;
  displayName?: string;
  email: string;
  photoURL?: string;
  role: 'user' | 'admin';
}

export interface SearchFilters {
  location: string;
  minPrice: number;
  maxPrice: number;
  rooms: number;
}
