import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, doc, getDoc } from '../firebase';
import { House } from '../types';
import { MapPin, BedDouble, Phone, MessageCircle, Calendar, User, ArrowLeft, Send, Mail } from 'lucide-react';
import { formatCurrency, getWhatsAppLink, cn } from '../lib/utils';
import { motion } from 'motion/react';

export default function HouseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [house, setHouse] = useState<House | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const fetchHouse = async () => {
      if (!id) return;
      const docRef = doc(db, 'houses', id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setHouse({ id: docSnap.id, ...docSnap.data() } as House);
      }
      setLoading(false);
    };
    fetchHouse();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
      </div>
    );
  }

  if (!house) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-stone-900">House not found</h2>
        <button onClick={() => navigate('/listings')} className="text-emerald-600 font-bold mt-4">Back to listings</button>
      </div>
    );
  }

  const images = house.images && house.images.length > 0 
    ? house.images 
    : [`https://picsum.photos/seed/${house.id}/1200/800`];

  const whatsappLink = getWhatsAppLink(house.landlordPhone, `Hi, I'm interested in your listing: ${house.title} in ${house.location}. Is it still available?`);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-stone-500 hover:text-stone-900 font-medium mb-8 transition-colors"
      >
        <ArrowLeft size={20} /> Back
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Left Column: Images & Info */}
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-4">
            <motion.div 
              key={activeImage}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="aspect-video rounded-3xl overflow-hidden bg-stone-100 shadow-2xl"
            >
              <img 
                src={images[activeImage]} 
                alt={house.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </motion.div>

            {images.length > 1 && (
              <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={cn(
                      "relative flex-shrink-0 w-24 aspect-square rounded-xl overflow-hidden border-2 transition-all",
                      activeImage === idx ? "border-emerald-500 scale-105" : "border-transparent opacity-60 hover:opacity-100"
                    )}
                  >
                    <img src={img} alt={`Thumbnail ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
            <div className="flex items-center gap-2 text-emerald-600 mb-4">
              <MapPin size={18} />
              <span className="text-sm font-bold uppercase tracking-widest">{house.location}</span>
            </div>
            <h1 className="text-4xl font-bold text-stone-900 mb-6">{house.title}</h1>
            
            <div className="flex flex-wrap gap-6 py-6 border-y border-stone-100 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center text-stone-400">
                  <BedDouble size={20} />
                </div>
                <div>
                  <p className="text-xs text-stone-400 font-bold uppercase tracking-tighter">Rooms</p>
                  <p className="font-bold text-stone-900">{house.rooms} Bedrooms</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-stone-50 rounded-xl flex items-center justify-center text-stone-400">
                  <Calendar size={20} />
                </div>
                <div>
                  <p className="text-xs text-stone-400 font-bold uppercase tracking-tighter">Posted</p>
                  <p className="font-bold text-stone-900">{house.createdAt.toDate().toLocaleDateString()}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold text-stone-900">Description</h3>
              <p className="text-stone-600 leading-relaxed whitespace-pre-wrap">
                {house.description}
              </p>
            </div>

            <div className="mt-10 pt-8 border-t border-stone-100 space-y-6">
              <h3 className="text-xl font-bold text-stone-900">Contact Information</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <a 
                  href={`tel:${house.landlordPhone}`}
                  className="flex items-center gap-4 p-4 bg-stone-50 rounded-2xl hover:bg-stone-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
                    <Phone size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-stone-400 font-bold uppercase">Phone</p>
                    <p className="font-bold text-stone-900">{house.landlordPhone}</p>
                  </div>
                </a>

                {house.landlordTelegram && (
                  <a 
                    href={`https://t.me/${house.landlordTelegram.replace('@', '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 bg-stone-50 rounded-2xl hover:bg-stone-100 transition-colors"
                  >
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-sky-500 shadow-sm">
                      <Send size={20} />
                    </div>
                    <div>
                      <p className="text-xs text-stone-400 font-bold uppercase">Telegram</p>
                      <p className="font-bold text-stone-900">@{house.landlordTelegram.replace('@', '')}</p>
                    </div>
                  </a>
                )}

                {house.landlordEmail && (
                  <a 
                    href={`mailto:${house.landlordEmail}`}
                    className="flex items-center gap-4 p-4 bg-stone-50 rounded-2xl hover:bg-stone-100 transition-colors"
                  >
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-stone-600 shadow-sm">
                      <Mail size={20} />
                    </div>
                    <div>
                      <p className="text-xs text-stone-400 font-bold uppercase">Email</p>
                      <p className="font-bold text-stone-900 truncate max-w-[150px]">{house.landlordEmail}</p>
                    </div>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Card */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-xl sticky top-24">
            <div className="mb-8">
              <p className="text-stone-400 font-bold text-sm uppercase mb-1">Monthly Rent</p>
              <h2 className="text-4xl font-bold text-emerald-600">{formatCurrency(house.price)}</h2>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-4 p-4 bg-stone-50 rounded-2xl">
                <div className="w-12 h-12 bg-stone-200 rounded-full flex items-center justify-center text-stone-500">
                  <User size={24} />
                </div>
                <div>
                  <p className="text-xs text-stone-400 font-bold uppercase">Landlord</p>
                  <p className="font-bold text-stone-900">{house.landlordName || 'Verified Landlord'}</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <a 
                href={`tel:${house.landlordPhone}`}
                className="flex items-center justify-center gap-2 w-full bg-stone-900 text-white py-4 rounded-2xl font-bold hover:bg-stone-800 transition-all"
              >
                <Phone size={20} /> Call Landlord
              </a>
              <a 
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-100"
              >
                <MessageCircle size={20} /> WhatsApp
              </a>
            </div>

            <p className="text-center text-xs text-stone-400 mt-6">
              Mention RentEthio when calling to get the best experience.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
