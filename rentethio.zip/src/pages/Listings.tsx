import React, { useEffect, useState } from 'react';
import { collection, db, getDocs, query, orderBy } from '../firebase';
import { House, SearchFilters } from '../types';
import HouseCard from '../components/HouseCard';
import SearchFilter from '../components/SearchFilter';
import { Search as SearchIcon, SlidersHorizontal } from 'lucide-react';

export default function Listings() {
  const [houses, setHouses] = useState<House[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    minPrice: 0,
    maxPrice: 0,
    rooms: 0
  });

  useEffect(() => {
    const fetchHouses = async () => {
      setLoading(true);
      const q = query(collection(db, 'houses'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const housesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as House));
      setHouses(housesData);
      setLoading(false);
    };
    fetchHouses();
  }, []);

  const filteredHouses = houses.filter(house => {
    const matchesLocation = house.location.toLowerCase().includes(filters.location.toLowerCase());
    const matchesMinPrice = filters.minPrice === 0 || house.price >= filters.minPrice;
    const matchesMaxPrice = filters.maxPrice === 0 || house.price <= filters.maxPrice;
    const matchesRooms = filters.rooms === 0 || house.rooms >= filters.rooms;
    return matchesLocation && matchesMinPrice && matchesMaxPrice && matchesRooms;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-12">
        <h1 className="text-4xl font-bold text-stone-900 mb-4">Browse Houses</h1>
        <p className="text-stone-500 max-w-2xl">Explore all available rental properties. Use the filters below to narrow down your search.</p>
      </div>

      <div className="mb-12">
        <SearchFilter filters={filters} onFilterChange={setFilters} />
      </div>

      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-2 text-stone-500">
          <SlidersHorizontal size={18} />
          <span className="font-medium">{filteredHouses.length} Properties found</span>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="bg-stone-100 animate-pulse rounded-2xl aspect-[4/5]" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredHouses.map(house => (
            <HouseCard key={house.id} house={house} />
          ))}
        </div>
      )}

      {!loading && filteredHouses.length === 0 && (
        <div className="text-center py-32 bg-white rounded-3xl border border-stone-200">
          <SearchIcon size={48} className="mx-auto text-stone-200 mb-4" />
          <h3 className="text-xl font-bold text-stone-900 mb-2">No results found</h3>
          <p className="text-stone-500">Try adjusting your filters or search terms.</p>
        </div>
      )}
    </div>
  );
}
