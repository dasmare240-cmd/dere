import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../App';
import { db, collection, addDoc, Timestamp, storage, ref, uploadBytes, getDownloadURL } from '../firebase';
import { MapPin, Phone, DollarSign, BedDouble, FileText, Image as ImageIcon, CheckCircle2, Upload, X, Loader2, Send, Mail } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function PostHouse() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    location: '',
    rooms: '1',
    landlordPhone: '',
    landlordTelegram: '',
    landlordEmail: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files: File[] = Array.from(e.target.files);
      setSelectedFiles(prev => [...prev, ...files]);
      
      const newPreviews = files.map((file: File) => URL.createObjectURL(file));
      setPreviews(prev => [...prev, ...newPreviews]);
    }
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setPreviews(prev => {
      const newPreviews = prev.filter((_, i) => i !== index);
      URL.revokeObjectURL(prev[index]);
      return newPreviews;
    });
  };

  const uploadImages = async (): Promise<string[]> => {
    const uploadPromises = selectedFiles.map(async (file) => {
      const storageRef = ref(storage, `houses/${user?.uid}/${Date.now()}-${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      return getDownloadURL(snapshot.ref);
    });
    return Promise.all(uploadPromises);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      setUploading(true);
      const imageUrls = await uploadImages();
      setUploading(false);

      await addDoc(collection(db, 'houses'), {
        landlordId: user.uid,
        landlordName: profile?.displayName || 'Landlord',
        landlordPhone: formData.landlordPhone,
        landlordTelegram: formData.landlordTelegram,
        landlordEmail: formData.landlordEmail,
        title: formData.title,
        description: formData.description,
        price: Number(formData.price),
        location: formData.location,
        rooms: Number(formData.rooms),
        images: imageUrls,
        createdAt: Timestamp.now()
      });
      setSuccess(true);
      setTimeout(() => navigate('/listings'), 2000);
    } catch (error) {
      console.error('Error adding house:', error);
      alert('Failed to post house. Please check your inputs.');
    } finally {
      setLoading(false);
      setUploading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-md mx-auto mt-32 text-center p-8 bg-white rounded-3xl shadow-xl border border-stone-100">
        <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h2 className="text-2xl font-bold text-stone-900 mb-2">Listing Posted!</h2>
        <p className="text-stone-500">Your house is now live on the marketplace. Redirecting you...</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-4xl font-bold text-stone-900 mb-2">Post a House</h1>
        <p className="text-stone-500">Fill in the details below to list your property for rent.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 bg-white p-8 rounded-3xl border border-stone-200 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <FileText size={16} className="text-stone-400" /> Listing Title
            </label>
            <input
              required
              type="text"
              name="title"
              placeholder="e.g. Modern 2 Bedroom Apartment"
              value={formData.title}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <MapPin size={16} className="text-stone-400" /> Location
            </label>
            <input
              required
              type="text"
              name="location"
              placeholder="e.g. Bole, Addis Ababa"
              value={formData.location}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <DollarSign size={16} className="text-stone-400" /> Monthly Rent (ETB)
            </label>
            <input
              required
              type="number"
              name="price"
              placeholder="e.g. 15000"
              value={formData.price}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <BedDouble size={16} className="text-stone-400" /> Number of Rooms
            </label>
            <select
              name="rooms"
              value={formData.rooms}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map(n => (
                <option key={n} value={n}>{n} {n === 1 ? 'Room' : 'Rooms'}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <Phone size={16} className="text-stone-400" /> Contact Phone
            </label>
            <input
              required
              type="tel"
              name="landlordPhone"
              placeholder="e.g. +251 911..."
              value={formData.landlordPhone}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <Send size={16} className="text-stone-400" /> Telegram Username
            </label>
            <input
              type="text"
              name="landlordTelegram"
              placeholder="e.g. username (without @)"
              value={formData.landlordTelegram}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
              <Mail size={16} className="text-stone-400" /> Contact Email
            </label>
            <input
              type="email"
              name="landlordEmail"
              placeholder="e.g. landlord@example.com"
              value={formData.landlordEmail}
              onChange={handleChange}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
            Description
          </label>
          <textarea
            required
            name="description"
            rows={4}
            placeholder="Describe the house, amenities, and neighborhood..."
            value={formData.description}
            onChange={handleChange}
            className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 transition-all outline-none resize-none"
          />
        </div>

        {/* Image Upload Section */}
        <div className="space-y-4">
          <label className="text-sm font-bold text-stone-700 flex items-center gap-2">
            <ImageIcon size={16} className="text-stone-400" /> House Photos
          </label>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-stone-200 rounded-2xl p-8 text-center hover:border-emerald-500 hover:bg-emerald-50 transition-all cursor-pointer group"
          >
            <input 
              type="file" 
              multiple 
              accept="image/*" 
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
            />
            <div className="w-12 h-12 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors">
              <Upload size={24} />
            </div>
            <p className="text-stone-600 font-medium">Click to upload photos</p>
            <p className="text-stone-400 text-sm">PNG, JPG or WEBP (max 10 photos)</p>
          </div>

          {/* Previews */}
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
            <AnimatePresence>
              {previews.map((url, index) => (
                <motion.div 
                  key={url}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="relative aspect-square rounded-xl overflow-hidden group"
                >
                  <img src={url} alt="Preview" className="w-full h-full object-cover" />
                  <button 
                    type="button"
                    onClick={() => removeFile(index)}
                    className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X size={14} />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold text-lg hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 size={20} className="animate-spin" />
              {uploading ? 'Uploading Images...' : 'Posting...'}
            </>
          ) : 'List Property'}
        </button>
      </form>
    </div>
  );
}
