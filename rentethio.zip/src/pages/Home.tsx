import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Search, Home as HomeIcon, ShieldCheck, Zap } from 'lucide-react';
import { collection, db, getDocs, query, orderBy, limit } from '../firebase';
import { House, SearchFilters } from '../types';
import HouseCard from '../components/HouseCard';
import SearchFilter from '../components/SearchFilter';
import { motion } from 'motion/react';

export default function Home() {
  const [newestHouses, setNewestHouses] = useState<House[]>([]);
  const [filters, setFilters] = useState<SearchFilters>({
    location: '',
    minPrice: 0,
    maxPrice: 0,
    rooms: 0
  });

  useEffect(() => {
    const fetchHouses = async () => {
      const q = query(collection(db, 'houses'), orderBy('createdAt', 'desc'), limit(3));
      const snapshot = await getDocs(q);
      const housesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as House));
      setNewestHouses(housesData);
    };
    fetchHouses();
  }, []);

  return (
    <div className="pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden bg-stone-900">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=80" 
            alt="Hero"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight"
          >
            Find Your Perfect <span className="text-emerald-400">Home</span> in Ethiopia
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-stone-300 mb-10 max-w-2xl mx-auto"
          >
            The most trusted platform for renting houses. Connect directly with landlords and find your next space today.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Link 
              to="/listings"
              className="inline-flex items-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-900/20"
            >
              Browse All Houses <ArrowRight size={20} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Search Filter Bar */}
      <div className="px-4">
        <SearchFilter filters={filters} onFilterChange={setFilters} />
      </div>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 mt-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
              <Search size={24} />
            </div>
            <h3 className="text-xl font-bold text-stone-900">Easy Search</h3>
            <p className="text-stone-500 leading-relaxed">Filter by location, price, and rooms to find exactly what you're looking for without the hassle.</p>
          </div>
          <div className="space-y-4">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
              <ShieldCheck size={24} />
            </div>
            <h3 className="text-xl font-bold text-stone-900">Trusted Landlords</h3>
            <p className="text-stone-500 leading-relaxed">We verify our listings to ensure you're connecting with real landlords and genuine properties.</p>
          </div>
          <div className="space-y-4">
            <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center">
              <Zap size={24} />
            </div>
            <h3 className="text-xl font-bold text-stone-900">Instant Contact</h3>
            <p className="text-stone-500 leading-relaxed">Connect via WhatsApp or phone call instantly. No middleman, no extra fees.</p>
          </div>
        </div>
      </section>

      {/* Newest Listings */}
      <section className="max-w-7xl mx-auto px-4 mt-32">
        <div className="flex items-end justify-between mb-12">
          <div>
            <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm">Marketplace</span>
            <h2 className="text-4xl font-bold text-stone-900 mt-2">Newest Listings</h2>
          </div>
          <Link to="/listings" className="text-stone-600 font-bold flex items-center gap-1 hover:text-emerald-600 transition-colors">
            View all <ArrowRight size={18} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {newestHouses.map(house => (
            <HouseCard key={house.id} house={house} />
          ))}
          {newestHouses.length === 0 && (
            <div className="col-span-full text-center py-20 bg-stone-100 rounded-3xl border-2 border-dashed border-stone-200">
              <HomeIcon size={48} className="mx-auto text-stone-300 mb-4" />
              <p className="text-stone-500 font-medium">No houses listed yet. Be the first to post!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
